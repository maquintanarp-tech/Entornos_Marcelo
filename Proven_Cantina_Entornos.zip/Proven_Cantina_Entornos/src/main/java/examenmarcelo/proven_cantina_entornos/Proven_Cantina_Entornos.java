/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package examenmarcelo.proven_cantina_entornos;

/**
 *
 * @author mqu1500
 */
public class Proven_Cantina_Entornos {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
