/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author mqu1500
 */
public class ModeloCarta {

    public double calcularPrecioMenu(TipusMenu menu, Ubicacio ubicacio) {

       
        double precioBase;

        switch (menu) {
            case MENU:
                precioBase = 9.0;
                break;
            case MIG_MENU:
                precioBase = 7.0;
                break;
            case MENU_VEGANO:
                precioBase = 10.0;
                break;
            default:
                return -1; 
        }

        
        double precioFinal;

        switch (ubicacio) {
            case INTERIOR:
                precioFinal = precioBase;
                break;
            case TERRASSA:
                precioFinal = precioBase * 1.05; 
                break;
            case FORA_PROVENCANA:
                precioFinal = precioBase + 1.0; 
                break;
            default:
                return -1; 
        }

        return precioFinal;
    }
}