/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package Modelo;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author isard
 */
public class ModeloCartaCompletoTest {
    
    private ModeloCarta carta = new ModeloCarta();

    // ========== CASOS 1,2,3: INTERIOR + ALUMNO ==========
    
    @Test
    public void test1_Menu9InteriorAlumno() {
        double resultado = carta.calcularPrecioMenu(TipusMenu.MENU, Ubicacio.INTERIOR, ZonaClient.ALUMNE_PROVENCANA);
        assertEquals(9.0, resultado);
    }

    @Test
    public void test2_MigMenu7InteriorAlumno() {
        double resultado = carta.calcularPrecioMenu(TipusMenu.MIG_MENU, Ubicacio.INTERIOR, ZonaClient.ALUMNE_PROVENCANA);
        assertEquals(7.0, resultado);
    }

    @Test
    public void test3_MenuVegano10InteriorAlumno() {
        double resultado = carta.calcularPrecioMenu(TipusMenu.MENU_VEGANO, Ubicacio.INTERIOR, ZonaClient.ALUMNE_PROVENCANA);
        assertEquals(10.0, resultado);
    }

    // ========== CASOS 4,5,6: TERRAZA + ALUMNO (+5%) ==========
    
    @Test
    public void test4_Menu9TerrazaAlumno() {
        double resultado = carta.calcularPrecioMenu(TipusMenu.MENU, Ubicacio.TERRASSA, ZonaClient.ALUMNE_PROVENCANA);
        assertEquals(9.45, resultado, 0.01);
    }

    @Test
    public void test5_MigMenu7TerrazaAlumno() {
        double resultado = carta.calcularPrecioMenu(TipusMenu.MIG_MENU, Ubicacio.TERRASSA, ZonaClient.ALUMNE_PROVENCANA);
        assertEquals(7.35, resultado, 0.01);
    }

    @Test
    public void test6_MenuVegano10TerrazaAlumno() {
        double resultado = carta.calcularPrecioMenu(TipusMenu.MENU_VEGANO, Ubicacio.TERRASSA, ZonaClient.ALUMNE_PROVENCANA);
        assertEquals(10.5, resultado, 0.01);
    }

    // ========== CASOS 7,8,9: INTERIOR + FUERA ZONA (+1€) ==========
    
    @Test
    public void test7_Menu9InteriorFora() {
        double resultado = carta.calcularPrecioMenu(TipusMenu.MENU, Ubicacio.INTERIOR, ZonaClient.ALUMNE_FORA);
        assertEquals(10.0, resultado);
    }

    @Test
    public void test8_MigMenu7InteriorFora() {
        double resultado = carta.calcularPrecioMenu(TipusMenu.MIG_MENU, Ubicacio.INTERIOR, ZonaClient.ALUMNE_FORA);
        assertEquals(8.0, resultado);
    }

    @Test
    public void test9_MenuVegano10InteriorFora() {
        double resultado = carta.calcularPrecioMenu(TipusMenu.MENU_VEGANO, Ubicacio.INTERIOR, ZonaClient.ALUMNE_FORA);
        assertEquals(11.0, resultado);
    }

    // ========== CASOS 10,11,12: TERRAZA + FUERA ZONA (+1€ Y +5%) ==========
    
    @Test
    public void test10_Menu9TerrazaFora() {
        double resultado = carta.calcularPrecioMenu(TipusMenu.MENU, Ubicacio.TERRASSA, ZonaClient.ALUMNE_FORA);
       assertEquals(10.5, resultado, 0.01);
    }

    @Test
    public void test11_MigMenu7TerrazaFora() {
        double resultado = carta.calcularPrecioMenu(TipusMenu.MIG_MENU, Ubicacio.TERRASSA, ZonaClient.ALUMNE_FORA);
        assertEquals(8.4, resultado, 0.01);
    }

    @Test
    public void test12_MenuVegano10TerrazaFora() {
        double resultado = carta.calcularPrecioMenu(TipusMenu.MENU_VEGANO, Ubicacio.TERRASSA, ZonaClient.ALUMNE_FORA);
        assertEquals(11.55, resultado, 0.01);
    }   

    // ========== CASOS 13 y 14: EXCEPCIONES ==========
    
   
        @Test
    public void test13_MenuNullLanzaExcepcion() {
        assertThrows(IllegalArgumentException.class, () -> {
            carta.calcularPrecioMenu(null, Ubicacio.INTERIOR, ZonaClient.ALUMNE_PROVENCANA);
        });
    }

    @Test
    public void test14_UbicacioNullLanzaExcepcion() {
        assertThrows(IllegalArgumentException.class, () -> {
            carta.calcularPrecioMenu(TipusMenu.MENU, null, ZonaClient.ALUMNE_PROVENCANA);
        });
    }
}