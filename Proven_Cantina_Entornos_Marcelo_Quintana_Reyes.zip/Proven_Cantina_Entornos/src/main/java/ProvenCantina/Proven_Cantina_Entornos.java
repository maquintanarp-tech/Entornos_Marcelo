/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ProvenCantina;

import Modelo.*;
import java.util.Scanner;

/**
 *
 * @author mqu1500
 */
public class Proven_Cantina_Entornos {

    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        ModeloCarta carta = new ModeloCarta();
        
        System.out.println("=====================================");
        System.out.println("   CANTINA PROVENÇANA - MENÚS");
        System.out.println("=====================================");
        System.out.println("");
        
        TipusMenu menu = null;
        Ubicacio ubicacio = null;
        ZonaClient zona = null;
        
        // =========================================
        // PREGUNTAR TIPO DE MENÚ (CON VALIDACIÓN)
        // =========================================
        boolean menuValido = false;
        while (!menuValido) {
            try {
                System.out.println("--- ELIGE TU MENÚ ---");
                System.out.println("1. MENÚ 9€");
                System.out.println("2. MIG MENÚ 7€");
                System.out.println("3. MENÚ VEGANO 10€");
                System.out.print("Opción (1-3): ");
                int opcionMenu = scanner.nextInt();
                
                switch (opcionMenu) {
                    case 1:
                        menu = TipusMenu.MENU;
                        System.out.println("✅ Has elegido: MENÚ 9€");
                        menuValido = true;
                        break;
                    case 2:
                        menu = TipusMenu.MIG_MENU;
                        System.out.println("✅ Has elegido: MIG MENÚ 7€");
                        menuValido = true;
                        break;
                    case 3:
                        menu = TipusMenu.MENU_VEGANO;
                        System.out.println("✅ Has elegido: MENÚ VEGANO 10€");
                        menuValido = true;
                        break;
                    default:
                        System.out.println("❌ ERROR: Opción no válida. Tienes que elegir 1, 2 o 3.");
                        System.out.println("   Inténtalo de nuevo.");
                        System.out.println("");
                        break;
                }
            } catch (Exception e) {
                System.out.println("❌ ERROR: Debes introducir un número (1, 2 o 3).");
                scanner.next(); // Limpiar el buffer
                System.out.println("");
            }
        }
        System.out.println("");
        
        // =========================================
        // PREGUNTAR UBICACIÓN (CON VALIDACIÓN)
        // =========================================
        boolean ubicacionValida = false;
        while (!ubicacionValida) {
            try {
                System.out.println("--- ¿DÓNDE QUIERES COMER? ---");
                System.out.println("1. INTERIOR");
                System.out.println("2. TERRAZA (+5%)");
                System.out.print("Opción (1-2): ");
                int opcionUbicacion = scanner.nextInt();
                
                switch (opcionUbicacion) {
                    case 1:
                        ubicacio = Ubicacio.INTERIOR;
                        System.out.println("✅ Has elegido: INTERIOR");
                        ubicacionValida = true;
                        break;
                    case 2:
                        ubicacio = Ubicacio.TERRASSA;
                        System.out.println("✅ Has elegido: TERRAZA (+5%)");
                        ubicacionValida = true;
                        break;
                    default:
                        System.out.println("❌ ERROR: Opción no válida. Tienes que elegir 1 o 2.");
                        System.out.println("   Inténtalo de nuevo.");
                        System.out.println("");
                        break;
                }
            } catch (Exception e) {
                System.out.println("❌ ERROR: Debes introducir un número (1 o 2).");
                scanner.next(); // Limpiar el buffer
                System.out.println("");
            }
        }
        System.out.println("");
        
        // =========================================
        // PREGUNTAR ZONA CLIENTE (CON VALIDACIÓN)
        // =========================================
        boolean zonaValida = false;
        while (!zonaValida) {
            try {
                System.out.println("--- ¿ERES ALUMNO DEL PROVENÇANA? ---");
                System.out.println("1. SÍ, soy alumno (precio normal)");
                System.out.println("2. NO, soy de fuera (+1€)");
                System.out.print("Opción (1-2): ");
                int opcionZona = scanner.nextInt();
                
                switch (opcionZona) {
                    case 1:
                        zona = ZonaClient.ALUMNE_PROVENCANA;
                        System.out.println("✅ Eres ALUMNO del Provençana");
                        zonaValida = true;
                        break;
                    case 2:
                        zona = ZonaClient.ALUMNE_FORA;
                        System.out.println("✅ Eres de FUERA del Provençana (+1€)");
                        zonaValida = true;
                        break;
                    default:
                        System.out.println("❌ ERROR: Opción no válida. Tienes que elegir 1 o 2.");
                        System.out.println("   Inténtalo de nuevo.");
                        System.out.println("");
                        break;
                }
            } catch (Exception e) {
                System.out.println("❌ ERROR: Debes introducir un número (1 o 2).");
                scanner.next(); // Limpiar el buffer
                System.out.println("");
            }
        }
        System.out.println("");
        
        // =========================================
        // CALCULAR PRECIO FINAL (CON TRY-CATCH)
        // =========================================
        System.out.println("=====================================");
        System.out.println("   CALCULANDO PRECIO FINAL...");
        System.out.println("=====================================");
        
        try {
            double precioFinal = carta.calcularPrecioMenu(menu, ubicacio, zona);
            
            System.out.println("");
            System.out.println("📋 RESUMEN DE TU PEDIDO:");
            System.out.println("   Menú: " + menu);
            System.out.println("   Ubicación: " + ubicacio);
            System.out.println("   Zona cliente: " + zona);
            System.out.println("");
            System.out.println("💰 PRECIO TOTAL: " + precioFinal + "€");
            System.out.println("");
            
        } catch (IllegalArgumentException e) {
            System.out.println("");
            System.out.println("❌ " + e.getMessage());
            System.out.println("");
            System.out.println("🔄 El programa se cerrará. Reinícialo para hacer un nuevo pedido.");
            System.exit(0);
        }
        
        // =========================================
        // PREGUNTAR SI QUIERE HACER OTRO PEDIDO
        // =========================================
        System.out.print("¿Quieres hacer otro pedido? (s/n): ");
        String repetir = scanner.next();
        
        if (repetir.equalsIgnoreCase("s")) {
            System.out.println("");
            System.out.println("");
            main(args);  // Vuelve a ejecutar el programa
        } else {
            System.out.println("");
            System.out.println("=====================================");
            System.out.println("   GRACIAS POR SU VISITA!");
            System.out.println("   ¡BUEN PROVECHO!");
            System.out.println("=====================================");
        }
        
        scanner.close();
    }
}