/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author mqu1500
 */
public class ModeloCarta {

public double calcularPrecioMenu(TipusMenu menu, Ubicacio ubicacio, ZonaClient zonaClient) {

      
        if (menu == null) {
            throw new IllegalArgumentException("❌ ERROR: No has elegido ningún menú. Tienes que elegir MENU, MIG_MENU o MENU_VEGANO.");
        }

        double precioBase;

        switch (menu) {
            case MENU:
                precioBase = 9.0;
                break;
            case MIG_MENU:
                precioBase = 7.0;
                break;
            case MENU_VEGANO:
                precioBase = 10.0;
                break;
            default:
                throw new IllegalArgumentException("❌ ERROR: Tipo de menú no válido. Las opciones son: MENU (9€), MIG_MENU (7€), MENU_VEGANO (10€)");
        }

       
        if (ubicacio == null) {
            throw new IllegalArgumentException("❌ ERROR: No has elegido ninguna ubicación. Tienes que elegir INTERIOR o TERRASSA.");
        }

        if (zonaClient == ZonaClient.ALUMNE_FORA) {
            precioBase = precioBase + 1.0;
        }

        if (ubicacio == Ubicacio.TERRASSA) {
            precioBase = precioBase * 1.05;
        }

        double precioFinal = Math.round(precioBase * 100.0) / 100.0;

        return precioFinal;
    }
}