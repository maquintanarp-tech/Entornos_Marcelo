/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package QuizzGUI;

import Vista.FinestraPrincipal;

/**
 *
 * @author mqu1500
 */
public class QuizzGui {
    
    public static void main(String[] args) {
        
       FinestraPrincipal app = new FinestraPrincipal();
       app.setVisible(true);
    }
    
}
