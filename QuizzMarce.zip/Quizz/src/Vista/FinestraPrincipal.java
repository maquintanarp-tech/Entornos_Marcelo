package Vista;


import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;


public class FinestraPrincipal extends JFrame implements ActionListener {
    
PanelPreguntas preg;
PanelSecundario sec ;
private ActionListener al;
JMenuBar barra;
JMenu opciones;
JMenuItem op1;
JMenuItem op2;
JMenuItem op3;

    public FinestraPrincipal() {
            al = this;
        initComponentsTitle();
        initContainer();
        initMenu();
    }

    private void initComponentsTitle() {
       
        
    this.setTitle("Pregunta de Logica");
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setSize(1500, 500);
    this.setLocationRelativeTo(null);  
        
    }

    private void initContainer() {
        
        Container principal = this.getContentPane();
        principal.removeAll();//borro lo que haya
        principal.setLayout(new GridLayout(1,1)); //podria ser grid 1,1 o borderLayout (center)
        preg = new PanelPreguntas();
        principal.add(preg);
        principal.revalidate(); //refrescar
        principal.repaint();
         
    }

    private void initMenu() {
       barra = new JMenuBar();
       opciones = new JMenu ("opciones");
       
       op1 = new JMenuItem("adivina");
       op2 = new JMenuItem("secundario");
       op3 = new JMenuItem("salir");
    
    opciones.add(op1);
    opciones.add(op2);
    opciones.add(op3);
    
    
    barra.add(opciones);
    this.setJMenuBar(barra);
    
    op1.setActionCommand("op1");
    op1.addActionListener(al);
    op2.setActionCommand("op2");
    op2.addActionListener(al);
    
    op3.setActionCommand("op3");
    op3.addActionListener(al);
    
    
    }

    
}

