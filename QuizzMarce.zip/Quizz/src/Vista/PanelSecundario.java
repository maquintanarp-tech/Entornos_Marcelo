/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author mqu1500
 */
public class PanelSecundario extends JPanel{
    
    JLabel j1;
    JButton b1;
    public PanelSecundario() {
        
        
        initComponents();
    }

    private void initComponents() {
        
      
        

    }
    
    
    
    
}
