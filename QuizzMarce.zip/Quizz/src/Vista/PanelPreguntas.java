package Vista;

import PersistenciaFicheros.LineReadFile;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;



public class PanelPreguntas extends JPanel implements ActionListener{

  
   private  JLabel pregunta , texto, opcion1,opcion2,opcion3,opcion4;
   private  JButton adivinar , inutil;
   private JTextField respuestausuario;
   private ActionListener al;
   String respuestaCorrecta = "" ;
    
    List<String> LiniaFicheros;
    
    public PanelPreguntas() {
       al = this;
       leerFichero();
       initComponents();
       initListeners();
       acertar();
       
    }

    private void initComponents() {
        
    this.setLayout(new GridLayout(5, 2));
    
    pregunta = new JLabel ("La pregunta es :");
    this.add(pregunta);
    
    texto = new JLabel (LiniaFicheros.get(0));
    this.add(texto);
    
    opcion1 = new JLabel (LiniaFicheros.get(1));
    this.add(opcion1);
    
    opcion2 = new JLabel (LiniaFicheros.get(2));
    this.add(opcion2);
    
    opcion3 = new JLabel (LiniaFicheros.get(3));
    this.add(opcion3);
    
    opcion4 = new JLabel (LiniaFicheros.get(4));
    this.add(opcion4);
    
    adivinar = new JButton("Adivinar");
    this.add(adivinar);
    
    
    respuestausuario = new JTextField ("..");
    this.add(respuestausuario);
    
    inutil = new JButton("inutil");
    this.add(inutil);
    

    
       
    }

    public JLabel getPregunta() {
        return pregunta;
    }

    public JLabel getTexto() {
        return texto;
    }

    public JLabel getOpcion1() {
        return opcion1;
    }

    public JLabel getOpcion2() {
        return opcion2;
    }

    public JLabel getOpcion3() {
        return opcion3;
    }

    public JLabel getOpcion4() {
        return opcion4;
    }

    public JButton getAdivinar() {
        return adivinar;
    }

    public JTextField getRespuestausuario() {
        return respuestausuario;
    }

    public JButton getInutil() {
        return inutil;
    }

    
    
 

    
    private void initListeners() {
        
        adivinar.setActionCommand("adivina");
        adivinar.addActionListener(al);
        inutil.setActionCommand("inutil");
        inutil.addActionListener(al);
    }
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        String comando = e.getActionCommand();
        System.out.println(comando);
        
        if (comando.equalsIgnoreCase("adivina")) {
            System.out.println("Voy a adivinar");
        }
        
        else if (comando.equalsIgnoreCase("inutil")) {
            System.out.println("Eres inutil");
        }
    }

    private void leerFichero() {
      LiniaFicheros = new ArrayList<>(); //Para qeu no sea NULL
       try {
           LineReadFile pregunta = new LineReadFile("Preguntas\\pregunta1.txt");
           
           String linea = pregunta.readLineFromFile();
 
            while (linea!=null)
            {
                if (linea.endsWith("*"))
                {
                    
                    /*el string linea se recorte a sin asterisco*/
                    /* recortando el string */
                    /*reemplanzando * por nada*/
                    linea = linea.substring(0, linea.length()-1);
                    //guardeis esta respuesta en una variable
       
                    respuestaCorrecta = linea;
                }
                
                LiniaFicheros.add(linea);
                linea = pregunta.readLineFromFile();
              
            }
               pregunta.tancarFitxers();
            
       } catch (FileNotFoundException ex) {
           System.out.println("");
       } catch (IOException ex) {
           Logger.getLogger(PanelPreguntas.class.getName()).log(Level.SEVERE, null, ex);
       }
            
    }

    private void acertar() {
       String respuestaU = respuestausuario.getText();
    
    
        if (respuestaU.equalsIgnoreCase(respuestaCorrecta)) {
             JOptionPane.showMessageDialog( this, "Muy bien Listillo" , "Acertaste" , JOptionPane.ERROR); 
             
             pregunta.setText("Muy bien listillo");
        }
    
        else {
            
            JOptionPane.showMessageDialog( this, "Eres imbecil" , "Error" , JOptionPane.ERROR);
        }
    }
    
    
}
