package Vista;


import java.awt.Container;
import java.awt.GridLayout;
import javax.swing.JFrame;


public class FinestraPrincipal extends JFrame {
    
PanelPreguntas preg;

    public FinestraPrincipal() {
        initComponentsTitle();
        initContainer();
    }

    private void initComponentsTitle() {
       
        
    this.setTitle("Pregunta de Logica");
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setSize(1500, 500);
    this.setLocationRelativeTo(null);  
        
    }

    private void initContainer() {
        
        Container principal = this.getContentPane();
        principal.removeAll();//borro lo que haya
        principal.setLayout(new GridLayout(1,1)); //podria ser grid 1,1 o borderLayout (center)
        preg = new PanelPreguntas();
        principal.add(preg);
        principal.revalidate(); //refrescar
        principal.repaint();
         
    }

    
}

